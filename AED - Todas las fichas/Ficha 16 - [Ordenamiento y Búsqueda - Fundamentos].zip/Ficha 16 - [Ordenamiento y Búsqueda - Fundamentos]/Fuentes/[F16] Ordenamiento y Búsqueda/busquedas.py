import arreglos
import random
import time


def validate(inf):
    n = inf
    while n <= inf:
        n = int(input('Ingrese cantidad de elementos (mayor a ' + str(inf) + ' por favor): '))
        if n <= inf:
            print('Error: se pidio mayor a', inf, '... cargue de nuevo...')

    return n


def generate(v):
    # cargar el arreglo con n datos aleatorios...
    n = len(v)
    for i in range(n):
        v[i] = random.randint(1, 1000)


def ordered(v):
    # cargar el arreglo con n datos ordenados...
    n = len(v)
    for i in range(n):
        v[i] = 3*i


def main():
    # cargar cantidad de elementos...
    n = validate(0)

    # crear un arreglo de n elementos (valor inicial 0)...
    v = n * [0]

    # cargar el arreglo con valores aleatorios...
    generate(v)

    m = int(input("Cuántas búsquedas quiere hacer?: "))

    # lanzar m busquedas secuenciales y medir el tiempo...
    t1 = time.perf_counter()
    for i in range(m):
        x = random.randint(1, 1000)
        r = arreglos.linear_search(v, x)
    t2 = time.perf_counter()
    tf = t2 - t1
    print("Terminadas", m, "búsquedas secuenciales en", tf, "segundos")
    input("Pulse <Enter> para continuar...")

    # volver a cargar el arreglo pero con valores ordenados...
    ordered(v)

    # lanzar m busquedas binarias y medir el tiempo...
    t1 = time.perf_counter()
    for i in range(m):
        x = random.randint(1, 1000)
        r = arreglos.binary_search(v, x)
    t2 = time.perf_counter()
    tf = t2 - t1
    print("Terminadas", m, "búsquedas binarias en", tf, "segundos")


# script principal...
if __name__ == '__main__':
    main()
