from ugraph import *


def main():
    n = 5
    ug = UnDirectedGraph(n)

    v = ["a", "b", "c", "d", "e"]
    print("¿Se agregaron nodos al grafo no dirigido?:", ug.add_nodes(v))

    ug.add_arc("a", "b")
    ug.add_arc("a", "c")
    ug.add_arc("b", "d")
    ug.add_arc("d", "a")
    ug.add_arc("e", "b")

    print("El grafo es:")
    print(ug)
    print("Cantidad de nodos del grafo:", ug.size())

    print()
    print("Cantidad de arcos incidentes al nodo 'a' (grado de 'a'):", ug.grade("a"))

    print()
    print("Hay arco entre 'a' y 'c'?:", ug.is_there_arc("a", "c"))
    ug.remove_arc("a", "c")
    print("Hay arco entre 'a' y 'c' (después de remover el arco)?:", ug.is_there_arc("a", "c"))


if __name__ == '__main__':
    main()
