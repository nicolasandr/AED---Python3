from dgraph import *


def main():
    n = 5
    dg = DirectedGraph(n)

    v = ["a", "b", "c", "d", "e"]
    print("¿Se agregaron nodos al grafo dirigido?:", dg.add_nodes(v))

    dg.add_arc("a", "b")
    dg.add_arc("a", "c")
    dg.add_arc("b", "d")
    dg.add_arc("d", "a")
    dg.add_arc("e", "b")

    print("El grafo es:")
    print(dg)
    print("Cantidad de nodos del grafo:", dg.size())

    print()
    print("Cantidad de arcos que salen desde el nodo 'a':", dg.output_grade("a"))
    print("Cantidad de arcos que llegan al nodo 'a':", dg.input_grade("a"))
    print("Cantidad de arcos incidentes al nodo 'a' (grado de 'a'):", dg.grade("a"))

    print()
    print("Hay arco entre 'a' y 'c'?:", dg.is_there_arc("a", "c"))
    dg.remove_arc("a", "c")
    print("Hay arco entre 'a' y 'c' (después de remover el arco)?:", dg.is_there_arc("a", "c"))


if __name__ == '__main__':
    main()
