__author__ = 'Ing. Valerio Frittelli'


def test():
    # observar que es valido escribirla en lineas separadas, por claridad...
    m0 = [[1, 3, 4], [3, 5, 2], [4, 7, 1]]
    print('Matriz 0 con valores fijos:', m0)

    # creación de una matriz de 3 * 4 elementos vacios...
    # ... Poner 0 en lugar de None si se quiere una matriz llena de ceros...
    m1 = []
    for f in range(3):
        m1.append([])
        for c in range(4):
            m1[f].append(None)
    print('Matriz 1 vacia:', m1)

    # otra manera mas compacta (y mas eficiente)...
    # ... solo necesita reemplazar el segundo None por 0 si quiere una matriz con ceros...
    # ... crea 3 componentes None (seran las filas...)
    m2 = [None] * 3
    for f in range(3):
        # ...expande cada fila a 4 elementos None
        m2[f] = [None] * 4
    print('Matriz 2 vacia:', m2)

    # y otra mas... usando comprension...
    # otra vez... reemplace el None por 0 si quiere una matriz de ceros...
    # para cada valor de f, agrega en m3 una lista de 4 valores None...
    m3 = [[None] * 4 for f in range(3)]
    print('Matriz 3 vacia:', m3)

    # acceso a un par de elementos individuales...
    m1[0][3] = 10
    m1[1][2] = 20
    print('Matriz 1 con dos cambios:', m1)

    # recorrido por filas de una matriz...
    for f in range(len(m2)):
        for c in range(len(m2[f])):
            m2[f][c] = f * c
    print('Matriz 2 modificada:', m2)

    # recorrido por columnas de una matriz...
    filas, columnas = 3, 4
    for c in range(columnas):
        for f in range(filas):
            m3[f][c] = f * c
    print('Matriz 3 modificada:', m3)

    # carga por teclado... recorrido por filas en orden creciente...
    filas, columnas = 3, 4
    m4 = [[0] * columnas for f in range(filas)]
    for f in range(filas):
        for c in range(columnas):
            m4[f][c] = int(input('Valor: '))
    print('Matriz 4 leida:', m4)

    # carga por teclado... recorrido por filas en orden decreciente...
    filas, columnas = 3, 4
    m5 = [[0] * columnas for f in range(filas)]
    for f in range(filas-1, -1, -1):
        for c in range(columnas):
            m5[f][c] = int(input('Valor: '))
    print('Matriz 5 leida:', m5)

    # carga por teclado... recorrido por columnas en orden decreciente...
    filas, columnas = 3, 4
    m6 = [[0] * columnas for f in range(filas)]
    for c in range(columnas):
        for f in range(filas):
            m6[f][c] = int(input('Valor: '))
    print('Matriz 6 leida:', m6)


if __name__ == '__main__':
    test()
