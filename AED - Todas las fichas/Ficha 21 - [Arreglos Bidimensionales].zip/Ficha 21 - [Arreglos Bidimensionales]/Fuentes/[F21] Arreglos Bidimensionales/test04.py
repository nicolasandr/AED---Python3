
def validate(inf):
    t = inf
    while t <= inf:
        t = int(input('Ingrese valor (mayor a ' + str(inf) + ' por favor): '))
        if t <= inf:
            print('Error: se pidio mayor a', inf, '... cargue de nuevo...')
    return t


def read(n):
    # crear y cargar por teclado una matriz cuadrada...
    mat = [[0] * n for f in range(n)]
    for f in range(n):
        for c in range(n):
            mat[f][c] = int(input('Valor [' + str(f) + '][' + str(c) + ']: '))
    return mat


def write(mat):
    n = len(mat)
    for f in range(n):
        print(mat[f])


def upper_triangle(mat):
    ac, n = 0, len(mat)
    for f in range(n-1):
        for c in range(f+1, n):
            ac += mat[f][c]
    return ac


def lower_triangle(mat):
    cp, n = 0, len(mat)
    for f in range(1, n):
        for c in range(0, f):
            if mat[f][c] % 2 == 0:
                cp += 1
    return cp


def diagonal(mat):
    cc, n = 0, len(mat)
    for f in range(n):
        if mat[f][f] == 0:
            cc += 1
    return cc


def test():
    print('Orden de la matriz cuadrada...')
    n = validate(0)
    print()

    print('Cargue la matriz...')
    mat = read(n)
    print()

    print('Contenido de la matriz:')
    write(mat)

    r1 = upper_triangle(mat)
    r2 = diagonal(mat)
    r3 = lower_triangle(mat)

    print('Acumulación del triángulo superior:', r1)
    print('Cantidad de ceros en la diagonal:', r2)
    print('Cantidad de pares en el triángulo inferior:', r3)


if __name__ == '__main__':
    test()
