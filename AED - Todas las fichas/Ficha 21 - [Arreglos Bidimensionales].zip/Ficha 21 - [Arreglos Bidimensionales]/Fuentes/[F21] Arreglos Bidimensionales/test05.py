class Consumo:
    def __init__(self, el, gs, ag):
        self.electricidad = el
        self.gas = gs
        self.agua = ag

    def __str__(self):
        r = ''
        r += '{:<35}'.format('Gasto de electricidad: ' + str(self.electricidad))
        r += '{:<17}'.format('Gas: ' + str(self.gas))
        r += '{:<17}'.format('Agua: ' + str(self.agua))
        return r


def validate(inf):
    n = inf
    while n <= inf:
        n = int(input('Valor (mayor a ' + str(inf) + ' por favor): '))
        if n <= inf:
            print('Error: se pidio mayor a', inf, '... cargue de nuevo...')
    return n


def read(fils, cols):
    cons = [[None] * cols for f in range(fils)]
    print('Ingrese los montos consumidos por cada rubro...')
    for f in range(fils):
        print('Propiedad', f, ':')
        for c in range(cols):
            print('\tMes', c)
            el = float(input('\t\tGasto en electricidad: '))
            gs = float(input('\t\tGasto en gas: '))
            ag = float(input('\t\tGasto en agua: '))

            cons[f][c] = Consumo(el, gs, ag)
            print()
    return cons


def display(cons):
    filas, columnas = len(cons), len(cons[0])
    print('Planilla de gastos mensuales por propiedad...')
    for f in range(filas):
        print('Propiedad', f)
        for c in range(columnas):
            print(cons[f][c])
    print()


def total_per_property(cons):
    filas, columnas = len(cons), len(cons[0])
    print('Gastos por propiedad en cada trimestre')
    for f in range(filas):
        ac = 0
        for c in range(columnas):
            t = cons[f][c].electricidad + cons[f][c].gas + cons[f][c].agua
            ac += t
        print('Propiedad:', f, '\tGasto total:', ac)


def total_per_month(cons):
    filas, columnas = len(cons), len(cons[0])
    print('Gastos por mes entre todas las propiedades')
    for c in range(columnas):
        ac = 0
        for f in range(filas):
            t = cons[f][c].electricidad + cons[f][c].gas + cons[f][c].agua
            ac += t
        print('Mes:', c, '\tGasto total:', ac)


def test():
    # cargar cantidad de propiedades...
    print('Cantidad de propiedades -', end=' ')
    fils = validate(0)
    print()

    # crear y cargar la matriz de consumos...
    cols = 3
    cons = read(fils, cols)
    print()

    # mostrar todos los datos cargados...
    display(cons)
    print()

    # acumulación por filas...
    total_per_property(cons)
    print()

    # acumulación por columnas...
    total_per_month(cons)


# script principal...
if __name__ == '__main__':
    test()
