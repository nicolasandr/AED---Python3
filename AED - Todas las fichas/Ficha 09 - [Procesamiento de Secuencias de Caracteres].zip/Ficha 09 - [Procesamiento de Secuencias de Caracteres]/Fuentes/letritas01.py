# titulo general...
print('Procesamiento de una secuencia de caracteres')
print('Version 1: cargando los caracteres uno a uno...')

# inicializacion de flags y contadores...
# contador de letras en una palabra...
cl = 0

# contador total de palabras...
ctp = 0

# contador de palabras que empiezan con "p"...
cpp = 0

# contador de palabras que tienen la expresion "ta"...
cta = 0

# flag: la ultima letra vista fue una "t"?...
st = False

# flag: se ha formado la silaba "ta" al menos una vez?...
sta = False

# instrucciones en pantalla...
print('Ingrese las letras del texto, pulsando <Enter> una a una')
print('(Para finalizar la carga, ingrese un punto)')
print()

# ciclo de carga - [1..N] (primera vualta forzada)...
car = None
while car != '.':
    # cargar proxima letra y contarla...
    car = input('Letra (con punto termina): ')
    cl += 1

    # fin de palabra?
    if car == ' ' or car == '.':
        # 1.) contar la palabra solo si hubo al menos una letra...
        if cl > 1:
            ctp += 1

        # 2.) si hubo 'ta' contar la palabra...
        if sta:
            cta += 1

        # reiniciar contador de letras...
        cl = 0

        # reiniciar flags...
        st = sta = False

        # regresar al ciclo ahora mismo...
        continue

    # 2.) deteccion de palabras que empiezan con "p"...
    if cl == 1 and car == 'p':
        cpp += 1

    # 3.) deteccion de expresion "ta"...
    if car == 't':
        st = True
    else:
        if car == 'a' and st:
            sta = True
        st = False

# visualización de los resultados finales...
print('1. Cantidad total de palabras:', ctp)
print('2. Cantidad de palabras que empiezan con "p":', cpp)
print('3. Cantidad de palabras con la expresion "ta":', cta)
