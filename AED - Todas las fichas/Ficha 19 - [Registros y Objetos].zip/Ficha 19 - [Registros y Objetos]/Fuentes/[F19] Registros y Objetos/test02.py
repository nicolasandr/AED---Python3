# declaración de un tipo registro vacío
class Empleado:
    pass


# creación de variables de tipo Empleado
e1 = Empleado()
e1.legajo = 1
e1.nombre = 'Juan'
e1.direccion = 'Calle 1'
e1.sueldo = 10000
e1.antiguedad = 10

e2 = Empleado()
e2.legajo = 2
e2.nombre = 'Luis'
e2.direccion = 'Calle 2'
e2.sueldo = 20000
e2.antiguedad = 15

e3 = Empleado()
e3.legajo = 3
e3.nombre = 'Pedro'
e3.direccion = 'Calle 3'
e3.sueldo = 25000
e3.antiguedad = 20

# creación de una variable Empleado con un campo adicional...
e4 = Empleado()
e4.legajo = 10
e4.nombre = 'Luis'
e4.direccion = 'Calle 4'
e4.sueldo = 50000
e4.antiguedad = 30
e4.cargo = 'Gerente'

# mostrar datos básicos...
print('Empleado 1 - Legajo:', e1.legajo, '- Nombre:', e1.nombre)
print('Empleado 2 - Legajo:', e2.legajo, '- Nombre:', e2.nombre)
print('Empleado 3 - Legajo:', e3.legajo, '- Nombre:', e3.nombre, '- Cargo:', e3.cargo)
print('Empleado 4 - Legajo:', e4.legajo, '- Nombre:', e4.nombre, '- Cargo:', e4.cargo)
