# declaración de un tipo registro vacío
class Empleado:
    pass


# una función para inicializar un registro de tipo Empleado
def init(empleado, leg, nom, direc, suel, ant):
    empleado.legajo = leg
    empleado.nombre = nom
    empleado.direccion = direc
    empleado.sueldo = suel
    empleado.antiguedad = ant


# una función para mostrar por consola estandar un registro de tipo Empleado
def write(empleado):
    print("\nLegajo:", empleado.legajo, end=' ')
    print("- Nombre:", empleado.nombre, end=' ')
    print("- Direccion:", empleado.direccion, end=' ')
    print("- Sueldo:", empleado.sueldo, end=' ')
    print("- Antiguedad:", empleado.antiguedad, end=' ')


# una funcion de prueba
def test():
    # creación de variables vacias de tipo Empleado...
    e1 = Empleado()
    e2 = Empleado()
    e3 = Empleado()

    # inicializacion de campos de las tres variables...
    init(e1, 1, 'Juan', 'Calle 1', 10000, 10)
    init(e2, 2, 'Luis', 'Calle 2', 20000, 15)
    init(e3, 3, 'Pedro', 'Calle 3', 25000, 20)

    # visualizacion de los valores de los tres registros...
    write(e1)
    write(e2)
    write(e3)


# script principal...
if __name__ == '__main__':
    test()




