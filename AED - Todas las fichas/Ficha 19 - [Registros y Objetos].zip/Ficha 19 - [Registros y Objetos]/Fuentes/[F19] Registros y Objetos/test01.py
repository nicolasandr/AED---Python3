# declaración de un tipo registro vacío
class Empleado:
    pass


# creación de variables de tipo Empleado
e1 = Empleado()
e1.legajo = 1
e1.nombre = 'Juan'
e1.direccion = 'Calle 1'
e1.sueldo = 10000
e1.antiguedad = 10

e2 = Empleado()
e2.legajo = 2
e2.nombre = 'Luis'
e2.direccion = 'Calle 2'
e2.sueldo = 20000
e2.antiguedad = 15

e3 = Empleado()
e3.legajo = 3
e3.nombre = 'Pedro'
e3.direccion = 'Calle 3'
e3.sueldo = 25000
e3.antiguedad = 20

# mostrar legajo y nombre de cada empleado...
print('Empleado 1 - Legajo:', e1.legajo, '- Nombre:', e1.nombre)
print('Empleado 2 - Legajo:', e2.legajo, '- Nombre:', e2.nombre)
print('Empleado 3 - Legajo:', e3.legajo, '- Nombre:', e3.nombre)

# algunas operaciones válidas...
# cambiar el legajo de e1...
e1.legajo = 4

# hacer que la antiguedad de e3 sea igual que la de e2...
e3.antiguedad = e2.antiguedad

# cargar por teclado el sueldo de e2...
e2.sueldo = float(input('Ingrese el nuevo sueldo del empleado 2: '))

# mostrar la direccion del empleado e1...
print('Direccion del empleado 1:', e1.direccion)

# sumar un año a la antiguedad de e3...
e3.antiguedad += 1

# mostrar todos los datos...
print('e1: Leg:', e1.legajo, '- Nom:', e1.nombre, '- Dir:', e1.direccion, '- Suel:', e1.sueldo, '- Ant:', e1.antiguedad)
print('e2: Leg:', e2.legajo, '- Nom:', e2.nombre, '- Dir:', e2.direccion, '- Suel:', e2.sueldo, '- Ant:', e2.antiguedad)
print('e3: Leg:', e3.legajo, '- Nom:', e3.nombre, '- Dir:', e3.direccion, '- Suel:', e3.sueldo, '- Ant:', e3.antiguedad)
