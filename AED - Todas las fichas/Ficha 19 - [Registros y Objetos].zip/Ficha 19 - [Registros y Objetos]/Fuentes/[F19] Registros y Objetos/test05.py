# declaración de un tipo registro vacío
class Empleado:
    pass


# una función para inicializar un registro de tipo Empleado
def init(leg, nom, direc, suel, ant):
    empleado = Empleado()
    empleado.legajo = leg
    empleado.nombre = nom
    empleado.direccion = direc
    empleado.sueldo = suel
    empleado.antiguedad = ant
    return empleado


# una función para mostrar por consola estandar un registro de tipo Empleado
def write(empleado):
    print("\nLegajo:", empleado.legajo, end=' ')
    print("- Nombre:", empleado.nombre, end=' ')
    print("- Direccion:", empleado.direccion, end=' ')
    print("- Sueldo:", empleado.sueldo, end=' ')
    print("- Antiguedad:", empleado.antiguedad, end=' ')


# una funcion de arranque a modo de prueba
def test():
    e1 = init(1, 'Juan', 'Calle 1', 10000, 10)
    write(e1)


# script principal...
if __name__ == '__main__':
    test()