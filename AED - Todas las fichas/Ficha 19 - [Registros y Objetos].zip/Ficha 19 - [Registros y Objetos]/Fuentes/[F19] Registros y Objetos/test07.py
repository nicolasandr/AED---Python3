# declaración de un tipo registro con un constructor
class Empleado:
    # un constructor...
    def __init__(self, leg=0, nom='No sabe', direc='No sabe', suel=0, ant=1):
        self.legajo = leg
        self.nombre = nom
        self.direccion = direc
        self.sueldo = suel
        self.antiguedad = ant

    # un método para mostrar un registro de tipo Empleado...
    def write(self):
        print("\nLegajo:", self.legajo, end=' ')
        print("- Nombre:", self.nombre, end=' ')
        print("- Direccion:", self.direccion, end=' ')
        print("- Sueldo:", self.sueldo, end=' ')
        print("- Antiguedad:", self.antiguedad, end=' ')


# La funcion de arranque del programa, a modo de prueba...
def test():
    # creación e inicialización de variables de tipo Empleado...
    # ... usando el constructor...
    e1 = Empleado(1, 'Juan', 'Calle 1', 10000, 10)
    e2 = Empleado(2, 'Luis', 'Calle 2', 20000, 15)
    e3 = Empleado(3, 'Pedro', 'Calle 3', 25000, 20)
    e4 = Empleado(4)

    # acceso a atributos...
    e4.nombre = "Ana"
    e4.sueldo = e3.sueldo + 10000
    e4.direccion = 'Calle 4'
    e4.antiguedad += 1

    # visualizacion de los valores de los tres registros...
    e1.write()
    e2.write()
    e3.write()
    e4.write()


# script principal...
if __name__ == '__main__':
    test()
