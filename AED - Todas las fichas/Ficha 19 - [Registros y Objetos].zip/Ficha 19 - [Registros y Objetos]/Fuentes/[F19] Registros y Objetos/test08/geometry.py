import math


class Point:
    def __init__(self, cx, cy, desc='p'):
        self.x = cx
        self.y = cy
        self.descripcion = desc

    def __str__(self):
        r = self.descripcion + '(' + str(self.x) + ', ' + str(self.y) + ')'
        return r

    def distance(self):
        # Pitágoras...
        return math.sqrt(pow(self.x, 2) + pow(self.y, 2))

    def gradient(self, p2):
        # calcular "delta y" y "delta x"
        dy = p2.y - self.y
        dx = p2.x - self.x

        # si los puntos no son colineales verticales,
        # retornar la pendiente...
        if dx != 0:
            return dy / dx

        # de otro modo, la pendiente es indefinida...
        # ... este retorno debería ser controlado al regresar...
        return None
