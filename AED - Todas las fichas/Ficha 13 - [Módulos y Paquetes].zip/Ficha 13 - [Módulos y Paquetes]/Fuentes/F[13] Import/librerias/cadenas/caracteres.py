__author__ = 'Cátedra de AED'


# una funcion que determina si la cadena tomada como parametro esta
# formada por un unico caracter que se repite
def caracter_unico(cadena):
    n = len(cadena)

    # si la cadena no tiene caracteres, retornar falso
    if n == 0:
        return False

    c0 = cadena[0]
    for i in range(1, n):
        if c0 != cadena[i]:
            return False
    return True
