__author__ = 'Cátedra de AED'

# se incluye este módulo solo como prueba...


def mensaje(m):
    print(m)

