# el autor del módulo...
__author__ = 'Cátedra de AED'

# los módulos que serán incluidos en un from numeros import *
__all__ = ['enteros', 'flotantes']
