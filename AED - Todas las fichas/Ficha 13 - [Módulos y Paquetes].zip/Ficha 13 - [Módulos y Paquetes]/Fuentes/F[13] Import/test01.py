__author__ = 'Cátedra de AED'

# el from - import que sigue importa SOLO los modulos "flotantes" y "enteros"...
# ver archivo __init__.py de este paquete...
from librerias.numeros import *


def test():
    p = flotantes.promedio(2.34, 4, 5.34)
    print("Promedio: ", p)

    m = enteros.menor(4,6)
    print("El menor es: ", 4)

    # testing.mensaje("Hola")


if __name__ == "__main__":
    test()

