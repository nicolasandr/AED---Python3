__author__ = 'Cátedra de AED'

# los from - import que siguen importan los contenidos de los modulos "flotantes" y "enteros"
from librerias.numeros.flotantes import *
from librerias.numeros.enteros import *


# el from - import que sigue importa la funcion caracter_unico()
from librerias.cadenas.caracteres import caracter_unico


def test():
    p = promedio(2.34, 4, 5.34)
    print('Promedio:', p)

    m = menor(4,6)
    print('El menor es:', 4)

    if caracter_unico('aaaaa'):
        print('La cadena tiene solo repeticiones de un unico caracter...')
    else:
        print('La cadena tiene varios caracteres distintos...')


if __name__ == '__main__':
    test()
