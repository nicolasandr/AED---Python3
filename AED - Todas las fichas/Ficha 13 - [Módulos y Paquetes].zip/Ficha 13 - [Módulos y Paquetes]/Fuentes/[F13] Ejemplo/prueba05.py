from soporte import *

__author__ = 'Cátedra de AED'
# Archivo prueba05.py


def test():
    a = int(input('Cargue un número entero: '))   
    f = factorial(a)
    print('El factorial del número es:', f)
    r = menor(a,f) 
    print('Menor:', r)
    

# script principal...
# si se pidió ejecutar ESTE modulo, entonces
# lanzar la funcion test()
if __name__ == "__main__" :
    test()
