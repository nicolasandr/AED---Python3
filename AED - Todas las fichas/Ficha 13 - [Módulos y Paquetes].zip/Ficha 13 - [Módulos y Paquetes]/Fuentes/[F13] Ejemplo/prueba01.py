__author__ = 'Cátedra de AED'

# Archivo prueba01.py
# Un programa en Python, que incluye al módulo soporte.py
import soporte


def test():
    a = int(input('Cargue el primer  número: '))
    b = int(input('Cargue el segundo número: '))

    # invocación a las funciones del módulo "soporte"
    m = soporte.menor(a,b)
    f = soporte.factorial(m)

    # si una función se va a usar mucho, se la puede referenciar con
    # un identificador local...
    men = soporte.menor
    c = men(3,5)
    print('Nuevo menor:', c)

    print('El menor es:', m)
    print('El factorial del menor es:', f)


# script principal...
test()
