from soporte import *
import prueba04

__author__ = 'Cátedra de AED'
# Archivo prueba03.py


def test():
    a = int(input('Cargue un número entero: '))
    f = factorial(a)
    print('El factorial del número es:', f)
    r = menor(a,f)
    print('Menor:', r)


# script principal...
test()
