__author__ = 'Cátedra de AED'

# archivo orden.py
# Este modulo contiene una función única a modo de ejemplo simple...


# una funcion para retornar el menor entre dos numeros...
def menor(n1, n2):
    if n1 < n2:
        return n1
    return n2
