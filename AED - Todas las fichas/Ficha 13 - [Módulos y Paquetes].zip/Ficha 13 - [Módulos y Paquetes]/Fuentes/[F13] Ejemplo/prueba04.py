import soporte

__author__ = 'Cátedra de AED'
# Archivo prueba04.py


def test():
    # invocacion a alguna funcion del modulo...
    # print('Factorial de 4:', soporte.factorial(4))

    # mostrar el nombre del modulo...
    print('Autor del modulo usado:', soporte.__author__)
    print('Nombre del modulo usado:', soporte.__name__)
    print('Nombre del módulo importado:', __name__)


# script principal...
if __name__ == '__main__':
    test()
