from soporte import menor, factorial

__author__ = 'Cátedra de AED'
# Archivo prueba02.py
# Un programa en Python, que incluye al módulo soporte.py


def test():
    a = int(input('Cargue un número entero: '))
    b = int(input('Cargue otro: '))
    m = menor(a, b)
    f = factorial(m)
    print('El menor es:', m)
    print('El factorial del menor es:', f)


# script principal...
test()
