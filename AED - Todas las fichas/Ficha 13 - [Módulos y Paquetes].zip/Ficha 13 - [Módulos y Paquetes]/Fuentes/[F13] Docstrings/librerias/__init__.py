"""El paquete contiene subpaquetes para operaciones con numeros y con cadenas.

Lista de subpaquetes incluidos:
:cadenas: Contiene un modulo con funciones para manejo de caracteres
:numeros: Contiene dos modulos con funciones para numeros enteros y en coma flotante
"""
__author__ = 'Cátedra de AED'
