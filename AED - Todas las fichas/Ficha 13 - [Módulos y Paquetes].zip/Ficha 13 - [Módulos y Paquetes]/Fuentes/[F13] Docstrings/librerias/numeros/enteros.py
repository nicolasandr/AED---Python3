"""Funciones generales para manejo de numeros enteros.

Lista de funciones incluidas:
:menor(n1, n2): Retorna el menor entre dos numeros
:factorial(n): Retorna el factorial de un numero entero
:ordenar(n1, n2, ascendent=True): Ordena dos numeros
"""
__author__ = 'Cátedra de AED'


def menor(n1, n2):
    """Retorna el menor entre dos numeros.

    :param n1: El primer numero a comparar
    :param n2: El segundo numero a comparar
    :return: El menor entre n1 y n2
    """
    if n1 < n2:
        return n1
    return n2


def factorial(n):
    """Retorna el factorial de un numero.

    :param n: El numero al cual se le calculara el factorial
    :return: El factorial de n, si n>=0. Si n<0, retorna None.
    """
    f = 1
    for i in range(2,n+1):
        f *= i
    return f


def ordenar(n1, n2, ascendent=True):
    """Ordena dos numeros.

    :param n1: El primero de los numeros a ordenar
    :param n2: El segundo de los numeros a ordenar
    :param ascendent: True para ordenamiento de menor a mayor - False en caso contrario
    :return: Los dos numeros, ordenados segun el criterio del parametro ascendent
    """
    first, second  = n2, n1
    if n1 < n2 :
        first, second = n1, n2
    if not ascendent :
        first, second = second, first
    return first, second
