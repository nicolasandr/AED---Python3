"""Funciones generales para manejo de numeros en coma flotante.

Lista de funciones incluidas:
:promedio (x1, x2, *x): Calcula el promedio en coma flotante entre todos sus parametros
"""
__author__ = 'Cátedra de AED'


def promedio (x1, x2, *x):
    """Obtener el promedio entre valores tomados como parametro.

    :param x1: El primero de los numeros a promediar
    :param x2: El segundo de los numeros a promediar
    :param x: Cualquier otro numero a promediar con x1 y x2.
    :return: El promedio en coma flotante entre todos los parametros.
    """
    suma = x1 + x2
    conteo = 2

    n = len(x)
    if n != 0 :
        for i in range(n):
            suma += x[i]
        conteo += n

    return suma / conteo
