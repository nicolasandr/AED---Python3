"""El paquete contiene dos modulos con funciones para operar con enteros y con flotantes.

Lista de modulos incluidos:
:enteros: Contiene funciones simples para manejo de numeros enteros
:flotantes: Contiene funciones simples para manejo de numeros en coma flotante
"""
__author__ = 'Cátedra de AED'
