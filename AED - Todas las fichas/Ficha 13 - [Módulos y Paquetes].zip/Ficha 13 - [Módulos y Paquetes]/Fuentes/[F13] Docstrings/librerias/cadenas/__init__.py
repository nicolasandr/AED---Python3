"""El paquete contiene un modulo con funciones para operar con caracteres y cadenas.

Lista de modulos incluidos:
:caracteres: Contiene funciones simples para manejo de caracteres
"""
__author__ = 'Cátedra de AED'
