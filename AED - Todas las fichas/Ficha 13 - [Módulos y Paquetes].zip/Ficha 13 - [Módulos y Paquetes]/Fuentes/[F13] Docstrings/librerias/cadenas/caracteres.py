"""Funciones generales para manejo de caracteres y cadenas.

Lista de funciones incluidas:
:caracter_unico(cadena) : Determina si cadena esta formada por un caracter unico
"""
__author__ = 'Cátedra de AED'


def caracter_unico(cadena):
    """Retorna True si la cadena analizada esta formada por un unico caracter que se repite.

    :param cadena : la cadena de caracteres a analizar
    :return : True si cadena contiene un unico caracter
    """
    n = len(cadena)

    # si la cadena no tiene caracteres, retornar falso
    if n == 0:
        return False

    c0 = cadena[0]
    for i in range(1, n):
        if c0 != cadena[i]:
            return False
    return True
