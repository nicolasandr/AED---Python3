__author__ = 'Cátedra de AED'

# Estos import acceden a los modulos "flotantes" y "caracteres"
import librerias.numeros.flotantes
import librerias.cadenas.caracteres


def test():
    p = librerias.numeros.flotantes.promedio(2.34, 4, 5.34)
    print('Promedio:', p)

    if librerias.cadenas.caracteres.caracter_unico('abcde'):
        print('La cadena tiene una o varias repeticiones de un unico caracter...')
    else:
        print('La cadena tiene varios caracteres distintos...')

    print('Contenidos docstring del paquete "librerias.cadenas":')
    print(librerias.cadenas.__doc__)


if __name__ == '__main__':
    test()
