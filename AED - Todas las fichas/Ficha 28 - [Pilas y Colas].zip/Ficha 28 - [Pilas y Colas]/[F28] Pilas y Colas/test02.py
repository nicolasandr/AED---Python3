import stack


def capicua(s):
    n = len(s)
    a = stack.Stack()

    mitad = n // 2
    if n % 2 == 1:
        d = mitad + 1
    else:
        d = mitad

    # fase 1: almacenar en la pila la mitad izquierda de la cadena...
    for i in range(mitad):
        a.push(s[i])

    # fase 2: recorrer la mitad derecha de la cadena y controlar
    # con lo que sale de la pila...
    for i in range(d, n):
        x = a.pop()
        if x != s[i]:
            return False
    return True


def main():
    s = input('Ingrese la cadena a analizar: ')
    res = capicua(s)
    if res:
        print('La cadena es capicúa...')
    else:
        print('La cadena no es capicúa...')


if __name__ == '__main__':
    main()
