class Stack:
    def __init__(self):
        """Crea una pila vacía.
        """
        self.items = []

    def __str__(self):
        """Retorna una cadena simple con el contenido de la pila.
        """
        return str(self.items)

    def is_empty(self):
        """Chequea si la pila está vacía.
        :return: True si pila está vacía - False en caso contrario.
        """
        n = len(self.items)
        return n == 0

    def peek(self):
        """Retorna el elemento del frente de la pila, sin eliminarlo.
        :return: el valor que está al frente, o None si la pila estaba vacía.
        """
        x = None
        if not self.is_empty():
            frente = -1
            x = self.items[frente]
        return x

    def push(self, x):
        """Inserta un elemento x al frente de la pila.
        :param x: el elemento a insertar.
        """
        self.items.append(x)

    def pop(self):
        """Elimina y retorna el elemento del frente de la pila.
        :return: el valor que estaba al frente, o None si la pila estaba vacía.
        """
        x = None
        if not self.is_empty():
            frente = -1
            x = self.items[frente]
            del self.items[frente]
        return x
