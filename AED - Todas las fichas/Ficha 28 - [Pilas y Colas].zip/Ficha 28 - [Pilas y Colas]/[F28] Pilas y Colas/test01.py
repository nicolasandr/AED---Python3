import stack


def main():
    p1 = stack.Stack()
    p1.push(5)
    p1.push(7)
    p1.push(2)
    p1.push(4)
    print('Estado actual de la pila:', p1)

    y = p1.pop()
    print('Elemento removido del frente:', y)

    x = p1.peek()
    print('Elemento actual al frente:', x)

    print('Estado actual de la pila:', p1)
    if p1.is_empty():
        print('La pila está vacía...')
    else:
        print('La pila no está vacía')

    while not p1.is_empty():
        print('Elemento removido:', p1.pop())

    print('Estado actual de la pila:', p1)
    if p1.is_empty():
        print('La pila está vacía...')
    else:
        print('La pila no está vacía')


if __name__ == '__main__':
    main()
