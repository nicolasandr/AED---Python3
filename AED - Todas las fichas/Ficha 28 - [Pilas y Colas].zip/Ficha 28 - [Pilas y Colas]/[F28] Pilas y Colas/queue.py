class Queue:
    def __init__(self):
        """Crea y retorna una cola vacía.
        """
        self.items = []

    def __str__(self):
        """Retorna una cadena simple con el contenido de la cola.
        """
        return str(self.items)

    def is_empty(self):
        """Chequea si la cola está vacía.
        :return: True si cola está vacía - False en caso contrario.
        """
        n = len(self.items)
        return n == 0

    def peek(self):
        """Retorna el elemento del frente de la cola, sin eliminarlo.
        :return: el valor que está al frente, o None si la cola estaba vacía.
        """
        x = None
        if not self.is_empty():
            x = self.items[0]
        return x

    def add(self, x):
        """Inserta un elemento x al fondo de la cola.
        :param x: el elemento a insertar.
        """
        self.items.append(x)

    def remove(self):
        """Elimina y retorna el elemento del frente de la cola.
        :return: el valor que estaba al frente, o None si la cola estaba vacía.
        """
        x = None
        if not self.is_empty():
            x = self.items[0]
            del self.items[0]
        return x
