import queue


def main():
    q1 = queue.Queue()
    q1.add(5)
    q1.add(7)
    q1.add(2)
    q1.add(4)
    print('Estado actual de la cola:', q1)

    y = q1.remove()
    print('Elemento removido del frente:', y)

    x = q1.peek()
    print('Elemento actual al frente:', x)

    print('Estado actual de la cola:', q1)
    if q1.is_empty():
        print('La cola está vacía...')
    else:
        print('La cola no está vacía')

    while not q1.is_empty():
        print('Elemento removido:', q1.remove())

    print('Estado actual de la cola:', q1)
    if q1.is_empty():
        print('La cola está vacía...')
    else:
        print('La cola no está vacía')


if __name__ == '__main__':
    main()
