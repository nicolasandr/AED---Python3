import calculos

__author__ = 'Catedra de Algoritmos y Estructuras de Datos'


def test():
    n = int(input('Ingrese un numero entero no negativo: '))
    print()

    print('Factorial (iterativo) de', n, ':', calculos.factorial01(n))
    print('Factorial (recursivo) de', n, ':', calculos.factorial02(n))
    print()

    print('Término', n, '-esimo de Fibonacci (iterativo):', calculos.fibonacci01(n))
    print('Término', n, '-esimo de Fibonacci (recursivo):', calculos.fibonacci02(n))
    print()


if __name__ == '__main__':
    test()

