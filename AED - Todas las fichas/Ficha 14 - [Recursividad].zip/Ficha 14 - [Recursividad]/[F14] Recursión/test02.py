import calculos

__author__ = 'Catedra de Algoritmos y Estructuras de Datos'


def test():
    n = int(input('Cuantos mensajes quiere ver? '))
    print()

    print('Primera version recursiva...')
    calculos.mostrar01(n)
    print()

    print('Segunda version recursiva...')
    calculos.mostrar02(n)


if __name__ == '__main__':
    test()