import pickle


def test():
    print('Procediendo a grabar números en el archivo prueba.num')
    m = open('prueba.num', 'wb')
    x, y = 12.345, 19
    pickle.dump(x, m)
    pickle.dump(y, m)
    m.close()

    m = open('prueba.num', 'rb')
    a = pickle.load(m)
    b = pickle.load(m)
    m.close()
    print('Datos recuperados desde el archivo:', a, ' - ', b)

    print('Hecho...')


if __name__ == '__main__':
    test()
