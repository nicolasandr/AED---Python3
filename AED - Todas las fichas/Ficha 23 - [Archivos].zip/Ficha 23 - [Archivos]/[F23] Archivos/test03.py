import pickle
import os.path


class Libro:
    def __init__(self, cod, tit, aut):
        self.isbn = cod
        self.titulo = tit
        self.autor = aut

    def __str__(self):
        r = 'ISBN: ' + str(self.isbn)
        r += ' - Título: ' + self.titulo
        r += ' - Autor: ' + self.autor
        return r


def test():
    print('Prueba de grabación de varios registros...')
    lib1 = Libro(2134, 'Fundación', 'Isaac Asimov')
    lib2 = Libro(5587, 'Fundación e Imperio', 'Isaac Asimov')
    lib3 = Libro(3471, 'Segunda Fundación', 'Isaac Asimov')
    lib4 = Libro(1122, 'Los Límites de la Fundación', 'Isaac Asimov')
    lib5 = Libro(2286, 'Fundación y Tierra', 'Isaac Asimov')

    fd = 'libros.dat'
    m = open(fd, 'wb')
    pickle.dump(lib1, m)
    pickle.dump(lib2, m)
    pickle.dump(lib3, m)
    pickle.dump(lib4, m)
    pickle.dump(lib5, m)
    m.close()
    print('Se grabaron varios registros en el archivo', fd)

    m = open(fd, 'rb')
    t = os.path.getsize(fd)

    print('Se recuperaron estos registros desde el archivo', fd, ':')
    while m.tell() < t:
        lib = pickle.load(m)
        print(lib)
    m.close()

    t = os.path.getsize(fd)
    print('Tamaño del archivo al terminar:', t, 'bytes')


if __name__ == '__main__':
    test()
