import random
import pickle
import os
import os.path
import io


class Libro:
    def __init__(self, cod, tit, aut):
        self.isbn = cod
        self.titulo = tit
        self.autor = aut

    def __str__(self):
        r = 'ISBN: ' + str(self.isbn)
        r += ' - Título: ' + self.titulo
        r += ' - Autor: ' + self.autor
        return r


def cargar_arreglo(v):
    n = int(input('Cuantos libros desea cargar?: '))
    for i in range(n):
        cod = random.randint(1, 10000)
        tit = 'Título ' + str(i)
        aut = 'Autor ' + str(i)
        lib = Libro(cod, tit, aut)
        v.append(lib)


def mostrar_arreglo(v):
    if len(v) == 0:
        print('No hay datos en el arreglo...')
        print()
        return

    print('Los libros registrados son:')
    for libro in v:
        print(libro)
    print()


def crear_archivo_todos(v, fd):
    if len(v) == 0:
        print('No hay datos en el arreglo...')
        print()
        return

    m = open(fd, 'wb')

    # forma 1: si se desea que el archivo contenga un vector...
    # pickle.dump(v, m)

    # forma 2: si se desea que al archivo contenga los registros
    # almacenados uno a uno en forma secuencial..
    for lib in v:
        pickle.dump(lib, m)

    m.close()
    print('Se creó el archivo', fd, 'con todos los registros del vector')
    print()


def mostrar_archivo(fd):
    if not os.path.exists(fd):
        print('El archivo', fd, 'no existe...')
        print()
        return

    print('Contenido actual del achivo', fd, ':')
    m = open(fd, 'rb')

    # forma 1: si el archivo contenía un vector...
    # v = pickle.load(m)
    # for lib in v:
    #    print(lib)

    # forma 2: si el archivo contenía registros almacenados
    # uno a uno en forma secuencial...
    t = os.path.getsize(fd)
    while m.tell() < t:
        lib = pickle.load(m)
        print(lib)
    m.close()
    print()


def crear_archivo_algunos(v, fd):
    if len(v) == 0:
        print('No hay datos en el arreglo...')
        print()
        return

    x = int(input('Ingrese el código a comparar: '))
    m = open(fd, 'wb')

    # forma 1: si se desea que el archivo contenga un vector...
    # v2 = []
    # for lib in v:
    #    if lib.isbn < x:
    #        v2.append(lib)
    # pickle.dump(v2, m)

    # forma 2: si se desea que al archivo contenga los registros
    # almacenados uno a uno en forma secuencial..
    for lib in v:
        if lib.isbn < x:
            pickle.dump(lib, m)
    m.close()
    print('Se creó el archivo', fd, 'con los registros con código <', x)
    print()


def crear_arreglo_todos(fd):
    if not os.path.exists(fd):
        print('El archivo', fd, 'no existe...')
        print()
        return

    m = open(fd, 'rb')

    # forma 1: si el archivo contenía un vector...
    # v = pickle.load(m)

    # forma 2: si el archivo contenía los registros almacenados
    # uno a uno en forma secuencial...
    v = []
    t = os.path.getsize(fd)
    while m.tell() < t:
        lib = pickle.load(m)
        v.append(lib)
    m.close()
    print('Se creó el vector con todo el contenido del archivo', fd)
    print()
    return v


def crear_arreglo_algunos(fd):
    if not os.path.exists(fd):
        print('El archivo', fd, 'no existe...')
        print()
        return

    x = int(input('Ingrese el código a comparar: '))
    m = open(fd, 'rb')

    # forma 1: si el archivo contenía un vector...
    # v = []
    # v2 = pickle.load(m)
    # for lib in v2:
    #    if lib.isbn > x:
    #        v.append(lib)

    # forma 2: si el archivo contenía los registros almacenados
    # uno a uno en forma secuencial...
    v = []
    t = os.path.getsize(fd)
    while m.tell() < t:
        lib = pickle.load(m)
        if lib.isbn > x:
            v.append(lib)
    m.close()
    print('Se creó el vector con parte del archivo', fd)
    print()
    return v


def test():
    v = []
    fd = 'libros.dat'
    op = -1
    while op != 8:
        print('Procesamiento combinado de arreglos, registros y archivos...')
        print('1. Crear el arreglo de libros (en forma automática)')
        print('2. Mostrar el arreglo de libros')
        print('3. Crear el archivo con TODOS los libros del arreglo')
        print('4. Mostrar el archivo de libros')
        print('5. Crear el archivo con ALGUNOS de los libros del arreglo')
        print('6. Volver a crear el arreglo con TODOS los libros del archivo')
        print('7. Volver a crear el arreglo con ALGUNOS de los libros del archivo')
        print('8. Salir')
        op = int(input('\t\tIngrese número de opción: '))
        print()

        if op == 1:
            cargar_arreglo(v)

        elif op == 2:
            mostrar_arreglo(v)

        elif op == 3:
            crear_archivo_todos(v, fd)

        elif op == 4:
            mostrar_archivo(fd)

        elif op == 5:
            crear_archivo_algunos(v, fd)

        elif op == 6:
            v = crear_arreglo_todos(fd)

        elif op == 7:
            v = crear_arreglo_algunos(fd)

        elif op == 8:
            pass


if __name__ == '__main__':
    test()
