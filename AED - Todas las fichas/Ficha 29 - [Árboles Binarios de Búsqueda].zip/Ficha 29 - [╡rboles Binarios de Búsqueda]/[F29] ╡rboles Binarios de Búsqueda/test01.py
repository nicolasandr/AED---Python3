from tree import *


def main():
    a = SearchTree()
    a.add(6)
    a.add(26)
    a.add(3)
    a.add(16)
    a.add(11)
    a.add(1)

    x = 16
    print("Contenido del árbol de búsqueda (en Entreorden):", a)
    print("Contenido del árbol de búsqueda (en Preorden):", a.preorder_travel())
    print("Contenido del árbol de búsqueda (en Postorden):", a.postorder_travel())

    print("Cantidad de nodos:", a.size())
    print("¿Está vacío el árbol?:", a.is_empty())
    print("¿Está contenido el valor", x, "en el árbol?:", a.contains(x))

    a.remove(6)
    print("Contenido del árbol de búsqueda (en Entre Orden) luego de eliminar un valor:", a)


if __name__ == '__main__':
    main()
