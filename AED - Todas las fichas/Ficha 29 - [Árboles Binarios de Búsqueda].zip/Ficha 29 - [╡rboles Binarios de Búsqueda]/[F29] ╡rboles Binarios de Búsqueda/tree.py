class TreeNode:
    def __init__(self, x, ls=None, rs=None):
        """Crea un nodo de árbol con valor igual a x, y sin hijos.
        """
        self.info = x
        self.left = ls
        self.right = rs

    def __str__(self):
        """Retorna la conversion a cadena del valor contenido en el nodo.
        :return: La conversión a cadena del nodo.
        """
        return str(self.info)


class SearchTree:
    def __init__(self):
        """Crea un árbol de búsqueda vacio.
        """
        self.root = None
        self.count = 0

    def __str__(self):
        """Crea una cadena con el contenido del árbol de búsqueda (recorrido en Entreorden).
        :return: La cadena con el recorrido en Entreorden del árbol de búsqueda.
        """
        return "| " + self.make_inorder(self.root) + "|"

    def preorder_travel(self):
        """Crea una cadena con el contenido del árbol de búsqueda (recorrido en Preorden).
        :return: La cadena con el recorrido en Preorden del árbol de búsqueda.
        """
        return "| " + self.make_preorder(self.root) + "|"

    def postorder_travel(self):
        """Crea una cadena con el contenido del árbol de búsqueda (recorrido en Postorden).
        :return: La cadena con el recorrido en Postorden del árbol de búsqueda.
        """
        return "| " + self.make_postorder(self.root) + "|"

    def is_empty(self):
        """Chequea si el árbol de búsqueda está vacío.
        :return: True si el árbol de búsqueda está vacío - False en caso contrario.
        """
        return self.root is None

    def add(self, x):
        """Inserta un elemento x en el árbol de búsqueda.
        :param x: el elemento a insertar.
        :return: True si la operación tuvo éxito.
        """
        if x is None:
            return False

        p = self.root
        q = None
        while p is not None:
            y = p.info
            if x == y:
                break
            q = p
            if x < y:
                p = p.left
            else:
                p = p.right

        # si x ya existía, no insertar y salir con False...
        if p is not None:
            return False

        # no existía... hay que insertar x...
        new = TreeNode(x)
        if q is None:
            self.root = new
        elif x < q.info:
            q.left = new
        else:
            q.right = new

        # contar el nuevo nodo...
        self.count += 1
        return True

    def remove(self, x):
        """Elimina un elemento x del árbol de búsqueda.
        :param x: el elemento a eliminar.
        :return: True si la operación tuvo éxito.
        """
        if x is None:
            return False

        ca = self.size()
        self.root = self.delete_node(self.root, x)
        return self.size() != ca

    def delete_node(self, p, x):
        """Auxiliar del método remove. Elimina en forma simple un nodo, pero solo si ese nodo
           tiene un solo hijo o ninguno.
        """
        if p is not None:
            y = p.info
            if x < y:
                menor = self.delete_node(p.left, x)
                p.left = menor
            else:
                if x > y:
                    mayor = self.delete_node(p.right, x)
                    p.right = mayor
                else:
                    # x encontrado... proceder a eliminarlo...
                    if p.left is None:
                        p = p.right
                    elif p.right is None:
                        p = p.left
                    else:
                        two = self.delete_with_two_children(p.left, p)
                        p.left = two

                    self.count -= 1
        return p

    def delete_with_two_children(self, d, p):
        """Auxiliar del método remove. Elimina un nodo, pero solo si ese nodo tiene dos hijos.
        """
        if d.right is not None:
            rs = self.delete_with_two_children(d.right, p)
            d.right = rs
        else:
            p.info = d.info
            d = d.left
        return d

    def contains(self, x):
        """Chequea si elemento x está en el árbol de búsqueda.
        :param x: el elemento a buscar.
        :return: True si x está en el árbol de búsqueda.
        """
        if x is None:
            return False

        p = self.root
        while p is not None:
            if x == p.info:
                return True

            elif x < p.info:
                p = p.left
            else:
                p = p.right

        return False

    def size(self):
        """Determina la cantidad de nodos del árbol de búsqueda.
        :return: El tamaño del árbol de búsqueda (total de nodos contenidos).
        """
        return self.count

    def make_inorder(self, p):
        """Crea una cadena con el contenido en Entreorden del árbol de búsqueda.
        :return: La cadena con el recorrido en Entreorden.
        """
        r = ""
        if p is not None:
            r = self.make_inorder(p.left)
            r += str(p) + " "
            r += self.make_inorder(p.right)
        return r

    def make_preorder(self, p):
        """Crea una cadena con el contenido en Pre Orden del árbol de búsqueda.
        :return: La cadena con el recorrido en Pre Orden.
        """
        r = ""
        if p is not None:
            r = str(p) + " "
            r += self.make_preorder(p.left)
            r += self.make_preorder(p.right)
        return r

    def make_postorder(self, p):
        """Crea una cadena con el contenido en Post Orden del árbol de búsqueda.
        :return: La cadena con el recorrido en Post Orden.
        """
        r = ""
        if p is not None:
            r = self.make_postorder(p.left)
            r += self.make_postorder(p.right)
            r += str(p) + " "
        return r
