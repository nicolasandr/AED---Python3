__author__ = 'Cátedra de AED'


def validar_mayor(lim):
    n = lim - 1
    while n <= lim:
        n = int(input('Valor mayor a ' + str(lim) + ' por favor: '))
        if n <= lim:
            print('\t\tError... se pidio mayor a', lim, '... cargue de nuevo...')
    return n


def insertion_sort(v):
    """Ordena el arreglo v de mayor a menor.

    Aplica el algoritmo de inserción simple para ordenar
    el arreglo v. El ordenamiento se hace de MAYOR a MENOR.

    :param v: el arreglo a ordenar.
    """
    n = len(v)
    for j in range(1, n):
        y = v[j]

        k = j - 1
        while k >= 0 and y > v[k]:
            v[k+1] = v[k]
            k -= 1

        v[k+1] = y


def greedy_change(x, coins):
    """Calcula la cantidad mínima de monedas para cambiar x.

    Aplica un algoritmo ávido para el cambio mínimo de x en
    monedas. El conjunto de monedas disponible se asume igual
    a [1, 5, 10, 25] (para el cual está garantizado que el
    algoritmo ávido funciona y calcula el cambio óptimo).

    :param x: el valor a cambiar.
    :param coins: el conjunto de monedas disponible.
    :return: la cantidad de monedas a retornar.
    """
    # chequear si existe una moneda única que sea la solución...
    for value in coins:
        if value == x:
            return 1

    # si no existe, ordenar coins de MAYOR a MENOR...
    insertion_sort(coins)

    # ... y aplicar la regla ávida...
    count, amount = 0, 0
    for value in coins:

        while amount + value <= x:
            amount += value
            count += 1

        if amount == x:
            break

    return count


def change():
    print('Cambio de Monedas: Solución con Algoritmo Ávido')

    coins = [1, 5, 10, 23, 50]
    print('Sistema monetario: - coins =', coins)
    print('(Nota: el programa funcionará SÓLO si coins es canónico...)')
    print()

    print('Monto a cambiar...')
    x = validar_mayor(0)

    cant = greedy_change(x, coins)
    print()
    print('Cantidad mínima de monedas a devolver:', cant)


if __name__ == '__main__':
    change()
