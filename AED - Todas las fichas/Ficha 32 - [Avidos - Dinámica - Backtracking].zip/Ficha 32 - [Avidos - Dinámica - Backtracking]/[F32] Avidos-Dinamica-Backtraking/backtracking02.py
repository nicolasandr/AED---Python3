__author__ = 'Cátedra de AED'


def intend(col):
    global rc, qr, qid, qnd, cs

    for fil in range(8):
        di = col + fil
        dn = (col - fil) + 7
        if qr[fil] and qid[di] and qnd[dn]:
            rc[col] = fil
            qr[fil] = qid[di] = qnd[dn] = False

            if col < 7:
                intend(col + 1)
            else:
                cs += 1
                print(rc, ' (', cs, ')', sep='')

            qr[fil] = qid[di] = qnd[dn] = True


def main():
    global rc, qr, qid, qnd, cs

    # rc[col] = índice de fila de la reina que está en la columna col...
    # ... todas en -1 pues aun no sabemos en qué fila quedará cada reina...
    rc = [-1] * 8

    # qr[fil] = true si la fila fil está libre de reinas...
    # ...inicialmente, todas las filas están libres de reinas...
    qr = [True] * 8

    # qid[k] = true si la diagonal inversa k está libre de reinas...
    # ...15 diagonales inversas... inicialmente todas libres de reinas...
    qid = [True] * 15

    # qnd[k] = true si la diagonal normal k está libre de reinas...
    # ...15 diagonales normales... inicialmente todas libres de reinas...
    qnd = [True] * 15

    # contador de soluciones...
    cs = 0

    print('Problema de las Ocho Reinas: Todas las soluciones con Backtraking')
    print()

    print('Distintas soluciones encontradas...')
    intend(0)


if __name__ == '__main__':
    main()
