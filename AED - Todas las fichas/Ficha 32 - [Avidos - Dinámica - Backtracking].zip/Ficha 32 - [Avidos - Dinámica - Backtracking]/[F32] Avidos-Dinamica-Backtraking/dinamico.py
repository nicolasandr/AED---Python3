__author__ = 'Cátedra de AED'


def validar_mayor(lim):
    n = lim - 1
    while n <= lim:
        n = int(input('Valor mayor a ' + str(lim) + ' por favor: '))
        if n <= lim:
            print('\t\tError... se pidio mayor a', lim, '... cargue de nuevo...')
    return n


def dinamic_change(x, coins):
    """Calcula la cantidad mínima de monedas para cambiar x.

    Algoritmo basado en programación dinámica: los resultados ya conocidos se
    almacenan en una tabla, y se consulta esa tabla para obtener datos que
    sirvan para resolver nuevos casos.

    :param x: el valor a cambiar.
    :param coins: el conjunto de monedas disponible.
    :return: la cantidad de monedas a retornar.
    """

    # cantidad de valores de monedas disponibles...
    n = len(coins)

    # tabla para los resultados previos del cambio de los valores menores a x...
    # ... incluyendo una casilla prev[x] para el cambio del propio valor x...
    # ... y prev[0] = 0 por el caso base: hacen falta 0 monedas para cambiar x = 0...
    prev = [0] * (x + 1)

    # calcular el mínimo para cada posible valor de v con 1 <= v <= x
    for v in range(1, x + 1):
        # empezamos suponiendo que el mínimo es el propio v...
        minv = v

        # ... y verificamos si hay alguna combinación menor...
        for j in range(n):
            # si coins[j] se pasa, seguir el ciclo...
            if coins[j] > v:
                continue

            ui = v - coins[j]
            if prev[ui] + 1 < minv:
                minv = prev[ui] + 1

        # ...almacenar el mínimo encontrado para v en prev[v]...
        prev[v] = minv

    # retornar el mínimo para x, que está en la última casilla...
    return prev[x]


def change():
    print('Cambio de Monedas: Solución con Programación Dinámica')

    coins = [1, 5, 10, 23, 50]
    print('Sistema monetario: - coins =', coins)
    print('(Nota: funcionará con cualquier sistema que incluya al 1, incluso no canónico o desordenado...)')
    print()

    print('Monto a cambiar...')
    x = validar_mayor(0)

    cant = dinamic_change(x, coins)
    print()
    print('Cantidad mínima de monedas a devolver:', cant)


if __name__ == '__main__':
    change()