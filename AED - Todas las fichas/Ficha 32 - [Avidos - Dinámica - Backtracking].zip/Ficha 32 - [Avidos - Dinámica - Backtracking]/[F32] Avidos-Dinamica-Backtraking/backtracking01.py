__author__ = 'Cátedra de AED'


def intend(col):
    global rc, qr, qid, qnd

    fil, res = -1, False
    while not res and fil != 7:
        res = False
        fil += 1
        di = col + fil
        dn = (col - fil) + 7
        if qr[fil] and qid[di] and qnd[dn]:
            rc[col] = fil
            qr[fil] = qid[di] = qnd[dn] = False
            if col < 7:
                res = intend(col + 1)
                if not res:
                    qr[fil] = qid[di] = qnd[dn] = True
            else:
                res = True

    return res


def main():
    global rc, qr, qid, qnd

    # rc[col] = índice de fila de la reina que está en la columna col...
    # ... todas en -1 pues aun no sabemos en qué fila quedará cada reina...
    rc = [-1] * 8

    # qr[fil] = true si la fila fil está libre de reinas...
    # ...inicialmente, todas las filas están libres de reinas...
    qr = [True] * 8

    # qid[k] = true si la diagonal inversa k está libre de reinas...
    # ...15 diagonales inversas... inicialmente todas libres de reinas...
    qid = [True] * 15

    # qnd[k] = true si la diagonal normal k está libre de reinas...
    # ...15 diagonales normales... inicialmente todas libres de reinas...
    qnd = [True] * 15

    print('Problema de las Ocho Reinas: Una solución con Backtraking')
    print()

    success = intend(0)
    if success:
        print('Solución posible encontrada:', rc)
    else:
        print('No hay solución posible para esa posición de partida...')


if __name__ == '__main__':
    main()
