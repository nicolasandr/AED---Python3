import random


def save_numbers(n, f='lista.txt'):
    """Crear un archivo con numeros aleatorios posiblemente repetidos (valores entre 1 y n).

    :param n: La cantidad de numeros a grabar en el archivo.
    :param f: El nombre del archivo a crear.
    """

    # asegurar el nombre por default del archivo...
    if not isinstance(f, str):
        f = 'lista.txt'

    # crear el archivo de texto, en modo grabacion...
    m = open(f, 'w')

    # en la primera linea, grabar como string la cantidad de numeros que tendrá el archivo...
    m.write(str(n) + '\n')

    # de aqui en mas, n lineas: una por cada numero, generado en forma aleatoria en [1, n]...
    for i in range(n):
        # pedir un entero aleatorio entre 1 y n (incluidos ambos)
        x = random.randint(1, n)

        # grabar el numero convertido a string, con el salto de linea si corresponde...
        m.write(str(x) + '\n')

    m.close()


def read_numbers(f='lista.txt'):
    """Crea una lista de numeros con el contenido del archivo f.

    :param f: El nombre del archivo desde el cual deben leerse los datos.
    :return: Una lista con todos los numeros que traia el archivo.
    """

    # asegurar el nombre por default del archivo...
    if not isinstance(f, str):
        f = 'lista.txt'

    # el arreglo a retornar, inicialmente vacio...
    lista = []

    # abrir el archivo de texto en modo de solo lectura...
    m = open(f)

    # la primera linea del archivo nos da el valor de n...
    # ...sirva o no, leerla y eliminar el '\n' del final...
    ln = m.readline()
    ln = ln[:-1]

    # ...convertirla a int...
    n = int(ln)

    # leer el resto del archivo...
    while True:
        # leer el siguiente numero...
        xs = m.readline()

        # controlar fin de archivo...
        if xs == '':
            break

        # si lo tenía, eliminar el caracter de salto de línea...
        # ... y convertir a entero...
        if xs[-1] == '\n':
            xs = xs[:-1]
        x = int(xs)

        # agregar el entero al arreglo en orden de llegada...
        lista.append(x)

    # cerrar el archivo y retornar el arreglo...
    m.close()
    return lista


def test():
    save_numbers(50)
    lis = read_numbers()
    print('La lista leida es:')
    print(lis)
    print('Cantidad de elementos:', len(lis))


if __name__ == '__main__':
    test()