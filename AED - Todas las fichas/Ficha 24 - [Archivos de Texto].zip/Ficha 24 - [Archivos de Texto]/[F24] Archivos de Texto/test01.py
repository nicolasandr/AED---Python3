def grabar_lineas():
    m = open('datos.txt', 'wt')
    m.write('Una linea de texto\n')
    m.write('Segunda linea de texto')
    m.close()


def leer_todo():
    m = open('datos.txt')
    todo = m.read()
    print('Contenido completo:')
    print(todo)
    m.close()


def leer_lineas():
    m = open('datos.txt')
    l1 = m.readline()
    l2 = m.readline()
    print('\nContenido linea por linea:')

    # agregar end="" para evitar el segundo salto de linea
    print(l1, end='')
    print(l2)
    m.close()


def leer_con_iterador():
    m = open('datos.txt')
    print('\nContenido con iterador:')
    for line in m:
        print(line, end='')
    print()
    m.close()


def lectura_controlada():
    m = open('datos.txt')
    print('\nContenido con control de lectura:')
    while True:
        # intentar leer una linea...
        line = m.readline()

        # si se obtuvo una cadena vacia... cortar el ciclo y terminar...
        if line == '':
            break

        # si lo tenía, eliminar el caracter de salto de línea...
        if line[-1] == '\n':
            line = line[:-1]

        # procesar la cadena resultante...
        print(line)

    # cerrar antes de irnos...
    m.close()


def lista_de_lineas():
    m = open('datos.txt')
    lista = m.readlines()
    print('\nLista de lineas contenidas:')
    print(lista)
    m.close()


def main():
    grabar_lineas()
    leer_todo()
    leer_lineas()
    leer_con_iterador()
    lectura_controlada()
    lista_de_lineas()


if __name__ == '__main__':
    main()
