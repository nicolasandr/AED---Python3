import io

def main():
    m = open('prueba', 'wt')
    m.write('Universidad')
    pos = m.tell()
    print('Posicion del file pointer / Longitud del archivo:', pos)

    # reposicionamiento correcto...
    m.seek(4, io.SEEK_SET)

    pos = m.tell()
    print('Posicion del file pointer ahora:', pos)

    # reposicionamiento correcto...
    m.seek(0, io.SEEK_END)

    pos = m.tell()
    print('Posicion del file pointer ahora:', pos)

    # lo siguiente provoca una excepcion...
    # m.seek(3, io.SEEK_CUR)

    print('Posicion del file pointer ahora:', pos)


if __name__ == '__main__':
    main()
