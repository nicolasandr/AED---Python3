import io
import os.path


def cargar_nombre():
    fd = input('Ingrese el nombre del archivo (incluya si quiere una extensión): ')
    print('Ok... nombre registrado...')
    print()
    return fd


def crear_archivo(fd):
    print('Archivo a crear:', fd)
    m = open(fd, 'wt')

    print('Ingrese líneas de texto, presionando <Enter> al final de cada una.')
    print('Para terminar la carga, incluya los caracteres ".-" al final de la línea')
    print()

    line = input()
    while not line.endswith('.-'):
        m.write(line + '\n')
        line = input()

    # eliminar el último guión...
    line = line[:-1]

    # grabar la última línea...
    m.write(line + '\n')

    m.close()
    print()
    print('Archivo creado y guardado...')
    print()


def abrir_archivo(fd):
    print('Archivo a abrir:', fd)
    m = open(fd, 'a+t')

    m.seek(0, io.SEEK_SET)
    print('Contenido actual del archivo:')
    print()

    for line in m:
        print(line, end='')

    print()
    print()
    print('Ingrese nuevas líneas de texto, para agregar al archivo,')
    print('presionando <Enter> al final de cada una.')
    print('Para terminar la carga, incluya los caracteres ".-" al final de la línea')
    print()

    line = input()
    while not line.endswith('.-'):
        m.write(line + '\n')
        line = input()

    # eliminar el guíón del final...
    line = line[:-1]

    # grabar la última línea...
    m.write(line + '\n')

    m.close()
    print()
    print('Archivo modificado y guardado...')
    print()


def listado_completo(fd):
    if not os.path.exists(fd):
        print('El archivo', fd, 'no existe... use las opciones 2 o 3 para crearlo...')
        print()
        return

    print('Archivo a mostrar:', fd)
    print()
    m = open(fd, 'rt')

    print('Contenido del archivo:')
    print()
    for line in m:
        print(line, end='')

    m.close()
    print()
    print()
    print('Archivo visualizado...')
    print()


def buscar_cadena(fd):
    if not os.path.exists(fd):
        print('El archivo', fd, 'no existe... use las opciones 2 o 3 para crearlo...')
        print()
        return

    print('Archivo a controlar:', fd)
    m = open(fd, 'rt')

    c = 0
    x = input('Ingrese la cadena a buscar: ')
    for line in m:
        c += line.count(x)

    m.close()
    print()
    print('La cadena', x, 'fue encontrada', c, 'veces en el archivo')
    print()


def duplicar_contenido(fd):
    if not os.path.exists(fd):
        print('El archivo', fd, 'no existe... use las opciones 2 o 3 para crearlo...')
        print()
        return

    print('Archivo a expandir:', fd)
    m = open(fd, 'r+t')

    # leer el contenido completo...
    todo = m.read()

    # grabar ese contenido al final...
    m.write(todo)

    m.close()
    print()
    print('Se duplicó y grabó el contenido del archivo')
    print()


def truncar_archivo(fd):
    if not os.path.exists(fd):
        print('El archivo', fd, 'no existe... use las opciones 2 o 3 para crearlo...')
        print()
        return

    print('Archivo a truncar:', fd)
    m = open(fd, 'r+t')

    c = 0
    cl = int(input('En cuántas líneas quiere truncar el archivo?: '))
    line = m.readline()
    while line != '':
        c += 1
        if c == cl:
            break
        line = m.readline()

    if c == cl:
        m.truncate(m.tell())
        print('Se truncó el contenido del archivo a', cl, 'lineas')
    else:
        print('No se truncó el archivo... no hay suficientes líneas...')

    m.close()
    print()


def main():
    # nombre físico por default del archivo...
    fd = 'default.txt'

    op = 0
    while op != 8:
        print('Opciones para gestión del archivo de texto:', fd)
        print('   1. Cargar nombre físico del archivo')
        print('   2. Crear archivo nuevo y grabar texto')
        print('   3. Abrir archivo y agregar texto al final')
        print('   4. Mostrar contenido completo del archivo')
        print('   5. Buscar y contar una palabra o cadena en el archivo')
        print('   6. Duplicar contenido del archivo (en el mismo archivo)')
        print('   7. Truncar contenido del archivo a dos líneas')
        print('   8. Salir')
        op = int(input('\t\tIngrese número de la opción elegida: '))
        print()

        if op == 1:
            fd = cargar_nombre()

        elif op == 2:
            crear_archivo(fd)

        elif op == 3:
            abrir_archivo(fd)

        elif op == 4:
            listado_completo(fd)

        elif op == 5:
            buscar_cadena(fd)

        elif op == 6:
            duplicar_contenido(fd)

        elif op == 7:
            truncar_archivo(fd)

        elif op == 8:
            pass


# script principal...
if __name__ == '__main__':
    main()