class Vehiculo:
    def __init__(self, pat, tip, cab, imp=0.0):
        self.patente = pat
        self.tipo = tip
        self.cabina = cab
        self.importe = imp

    def __str__(self):
        r = ''
        r += '{:<20}'.format('Patente: ' + self.patente)
        r += '{:<20}'.format('Tipo: ' + str(self.tipo))
        r += '{:<20}'.format('Cabina: ' + str(self.cabina))
        r += '{:<20}'.format('Importe: ' + str(self.importe))
        return r
