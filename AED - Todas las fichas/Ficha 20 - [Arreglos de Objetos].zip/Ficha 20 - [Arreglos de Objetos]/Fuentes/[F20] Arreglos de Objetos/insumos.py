class Insumo:
    def __init__(self, cod=1, nom='', pre=0.0, cant=0):
        self.codigo = cod
        self.nombre = nom
        self.valor = pre
        self.cantidad = cant

    def __str__(self):
        r = ''
        r += '{:<15}'.format('Codigo: ' + str(self.codigo))
        r += '{:<30}'.format('Nombre: ' + self.nombre)
        r += '{:<18}'.format('Precio: ' + str(self.valor))
        r += '{:<15}'.format('Cantidad: ' + str(self.cantidad))
        return r
