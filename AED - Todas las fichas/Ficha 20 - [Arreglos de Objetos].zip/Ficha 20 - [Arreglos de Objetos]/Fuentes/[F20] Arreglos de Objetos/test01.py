class Estudiante:
    def __init__(self, leg=0, nom='', pro=0):
        self.legajo = leg
        self.nombre = nom
        self.promedio = pro

    def __str__(self):
        return 'Legajo: ' + str(self.legajo) + ' - Nombre: ' + self.nombre + ' - Promedio: ' + str(self.promedio)


def validate(inf):
    n = inf
    while n <= inf:
        n = int(input('Ingrese cantidad de elementos (mayor a ' + str(inf) + ' por favor): '))
        if n <= inf:
            print('Error: se pidio mayor a', inf, '... cargue de nuevo...')
    return n


def read(estudiantes):
    n = len(estudiantes)
    for i in range(n):
        leg = int(input('Legajo[' + str(i) + ']: '))
        nom = input('Nombre: ')
        pro = float(input('Promedio: '))
        print()
        estudiantes[i] = Estudiante(leg, nom, pro)


def sort(estudiantes):
    n = len(estudiantes)
    for i in range(n-1):
        for j in range(i+1, n):
            if estudiantes[i].legajo > estudiantes[j].legajo:
                estudiantes[i], estudiantes[j] = estudiantes[j], estudiantes[i]


def display(estudiantes, x):
    n = len(estudiantes)
    print('Estudiantes que harán el curso (tienen promedio >=', x, '):')
    for i in range(n):
        if estudiantes[i].promedio >= x:
            print(estudiantes[i])


def test():
    # cargar cantidad de estudiantes...
    n = validate(0)

    # crear un arreglo con n casilleros de valor indefinido...
    # ... se usará para almacenar luego las referencias a los Estudiantes...
    estudiantes = n * [None]

    # cargar el arreglo por teclado...
    print('\nCargue los datos de los estudiantes:')
    read(estudiantes)
    print()

    x = float(input('Promedio mínimo para poder hacer el curso: '))
    print()

    # ordenar de menor a mayor el arreglo, por legajo...
    sort(estudiantes)

    # mostrar por pantalla el listado...
    display(estudiantes, x)


# script principal...
if __name__ == '__main__':
    test()
