class Socio:
    def __init__(self, num, nom='', ara=0.0, cod=0):
        self.numero = num
        self.nombre = nom
        self.arancel = ara
        self.codigo = cod

    def __str__(self):
        r = ''
        r += '{:<15}'.format('Numero: ' + str(self.numero))
        r += '{:<30}'.format('Nombre: ' + self.nombre)
        r += '{:<18}'.format('Arancel: ' + str(self.arancel))
        r += '{:<15}'.format('Codigo: ' + str(self.codigo))
        return r
