class Estudiante:
    def __init__(self, leg, nom, pro, year):
        self.legajo = leg
        self.nombre = nom
        self.promedio = pro
        self.ingreso = year

    def __str__(self):
        r = "Legajo: " + str(self.legajo)
        r += " - Nombre: " + self.nombre
        r += " - Promedio: " + str(self.promedio)
        r += " - Ingreso: " + str(self.ingreso)
        return r


def cargar(n):
    v = n * [None]
    for i in range(n):
        leg = int(input("Legajo: "))
        nom = input("Nombre: ")
        pro = float(input("Promedio: "))
        ing = int(input("Ingreso: "))
        v[i] = Estudiante(leg, nom, pro, ing)
    return v


def ordenar(v):
    n = len(v)
    for i in range(n-1):
        for j in range(i+1, n):
            if v[i].legajo > v[j].legajo:
                v[i], v[j] = v[j], v[i]


def mostrar(v):
    n = len(v)
    print("Listado de niñitos...")
    for i in range(n):
        print(v[i])


def buscar(v, nom):
    n = len(v)
    for i in range(n):
        if nom == v[i].nombre:
            return i
    return -1


def mostrar_ingreso(v, x):
    n = len(v)
    c = 0
    print("Listado de niñitos que ingresaron después de", x)
    for i in range(n):
        if v[i].ingreso > x:
            print(v[i])
            c += 1
    if c == 0:
        print("No había ninguno...")


def principal():
    print("Gestión de estudiantes...")
    n = int(input("Cuántos estudiantes serán? "))
    v = cargar(n)

    ordenar(v)
    mostrar(v)

    nom = input("Nombre a buscar: ")
    ind = buscar(v, nom)
    if ind >= 0:
        print("Encontrado...")
        print(v[ind])
    else:
        print("No existe ese niñito...")

    x = int(input("Año de referencia: "))
    mostrar_ingreso(v, x)


if __name__ == "__main__":
    principal()